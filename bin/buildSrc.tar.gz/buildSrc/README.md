# buildSrc plugin

This  template module should work with Android project.

Gradle treats `buildSrc` as plugin directory while Android Studio not. With this generated template we can make Android Studio work too. both code highlight and coding suggestion should just work fine.